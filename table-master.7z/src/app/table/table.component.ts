import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';
import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Observable, } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { UtilityService } from '../utility.service';
import { Clipboard } from '@angular/cdk/clipboard';

@Component({
  selector: 'smart-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit, OnChanges {
  movies = [
    'Episode I - The Phantom Menace',
    'Episode II - Attack of the Clones',
    'Episode III - Revenge of the Sith',
    'Episode IV - A New Hope',
    'Episode V - The Empire Strikes Back',
    'Episode VI - Return of the Jedi',
    'Episode VII - The Force Awakens',
    'Episode VIII - The Last Jedi',
    'Episode IX – The Rise of Skywalker',
  ];
  value =
    `Did you ever hear the tragedy of Darth Plagueis The Wise? I thought not. It's not ` +
    `a story the Jedi would tell you. It's a Sith legend. Darth Plagueis was a Dark Lord ` +
    `of the Sith, so powerful and so wise he could use the Force to influence the ` +
    `midichlorians to create life… He had such a knowledge of the dark side that he could ` +
    `even keep the ones he cared about from dying. The dark side of the Force is a pathway ` +
    `to many abilities some consider to be unnatural. He became so powerful… the only ` +
    `thing he was afraid of was losing his power, which eventually, of course, he did. ` +
    `Unfortunately, he taught his apprentice everything he knew, then his apprentice ` +
    `killed him in his sleep. Ironic. He could save others from death, but not himself.`;


  drop2(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.headers, event.previousIndex, event.currentIndex);
  }
  dropSortable(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.sorts, event.previousIndex, event.currentIndex);
    this.refresh();
  }

  @Input()
  data: Array<any>;
  @Input()
  headers: Array<{ key: string, val: string, action: any }>;
  sliderValue = 3;
  page = 1;
  pageSize = 10;
  total: number;
  results$: Observable<any>;
  sorts = [];
  dirs = { asc: 'desc', desc: '', '': 'asc' };
  oldPageSize = 10;
  isSearchAll = false;
  columnSearchFG: FormGroup;
  constructor(private service: UtilityService, private datePipe: DatePipe, private fb: FormBuilder,
    private clipboard: Clipboard) {

  }
  copy(): void {
    this.results$.subscribe(x => {
      this.clipboard.copy(this.createCopyText(this.data, this.headers));
    });
  }

  print(): void {
    var printdata = document.getElementById("tableInformation").outerHTML;

    var tab = window.open('') as Window;
    tab.document.open();
    tab.document.write(printdata);
    // tab.close();
    // tab.focus();
    // tab.print();
    // tab.close();

    setTimeout(() => {
      tab.stop();
      tab.print();
      tab.close();
    }, 300);


    return;
    const printContent = document.getElementById("tableInformation");
    const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
    WindowPrt.document.write(printContent.innerHTML);
    WindowPrt.document.close();
    WindowPrt.focus();
    WindowPrt.print();
    WindowPrt.close();
  }
  createCopyText(data: Array<any>, headers: Array<{ key: string, val: string }>): string {
    const dataStr = data.map(row =>
      headers.reduce((prev, next) => [...prev, row[next.key]], []).join('\t')
    ).join('\n');
    return headers.reduce((prev, next) => [...prev, next.val], []).join('\t') + '\n' + dataStr;
  }


  ngOnChanges(changes: SimpleChanges): void {
    if (!this.headers) {
      return;
    }
    this.total = this.data?.length;
    const ctrls = this.headers.reduce((prev, next) => ({ ...prev, [next.key]: [null] }), {});
    this.columnSearchFG = this.fb.group(ctrls);
    this.columnSearchFG.addControl('searchTerm', new FormControl());
    this.results$ = this.columnSearchFG.valueChanges.pipe(
      startWith(''),
      map(term => {
        return this.filterTerms();
      }));
  }

  sort(arr: Array<any>, keys: Array<string>) {
  }

  sortBy(key: string, event) {
    const withCtrlKey = event.metaKey || event.ctrlKey;
    const sortObject = this.sorts.find(x => x.key === key);
    if (sortObject) {
      sortObject.dir = this.dirs[sortObject.dir];
    }
    else {
      if (withCtrlKey) {
        this.sorts.push({ dir: 'asc', key });
      }
      else {
        this.sorts = [{ dir: 'asc', key }];
      }
    }
    this.searchTerm.setValue(this.term);
  }

  filterTerms(exportExcel = false): Array<any> {

    const headers = this.headers.map(x => x.key);
    let filtered;
    if (this.isSearchAll) {
      filtered = this.service.filter(this.data, headers, this.term);
    } else {
      filtered = this.service.filterTerms(this.data, headers, headers.map(x => this.columnSearchFG.controls[x].value));
    }
    return this.sortAndPaginateFiltered(filtered, exportExcel);
  }

  sortAndPaginateFiltered(filtered: Array<any>, exportExcel = false): Array<any> {
    if (filtered.length <= this.pageSize) {
      this.page = 1;
    }
    this.total = filtered.length;
    const sorted = this.service.sort([...filtered], this.sorts.map(x => x.key),
      this.sorts.map(x => x.dir === 'asc' ? true : (x.dir === 'desc' ? false : null)));
    if (this.pageSize === null || exportExcel) {
      this.oldPageSize = null;
      return sorted;
    }
    this.page = this.service.setPageSize(this.pageSize, this.page, this.oldPageSize, sorted.length);
    const startIndex = (this.page - 1) * this.pageSize;

    this.oldPageSize = this.pageSize;

    return sorted.slice(startIndex, startIndex + this.pageSize);
  }

  ngOnInit(): void {
    if (!this.data) {
      return;
    }
    this.total = this.data?.length;
  }

  get searchTerm() {
    return this.columnSearchFG.get('searchTerm');
  }

  get term() {
    return this.columnSearchFG.get('searchTerm').value;
  }

  set setTerm(term: string) {
    this.searchTerm.setValue(term);
  }

  refresh() {
    this.setTerm = this.term;
  }

  getSortByKey(key: string) {
    return this.sorts.find(x => x.key === key);
  }

  toDate(date: Date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  isDate(data: any): boolean {
    return this.service.isDate(data);
  }

  changePageSize(event) {
    this.searchTerm.setValue(this.term);
  }

  exportToExcel() {

    this.service.exportToExcel(this.headers, this.filterTerms(true));
  }

  removeSort(x: string) {
    this.sorts = this.sorts.filter(sort => sort.key != x);
    this.refresh();
  }

  load() {

  }
}

