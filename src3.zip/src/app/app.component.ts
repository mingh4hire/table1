import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ChangeDetectorRef, Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'abc';
  headers;
  data;
  dataservice: DataService;

  action1 = function (row) {
    row.id = 33;
    console.log('data is ', this.dataservice.data);
  }

  constructor(private http: HttpClient, detector: ChangeDetectorRef,
    dataservice: DataService) {
    this.dataservice = dataservice;
    this.http.get('https://jsonplaceholder.typicode.com/todos').subscribe(
      x => {
        this.data = x;
        this.dataservice.data = x;
        this.data.forEach(row => {
          row.date = new Date(2019, Math.ceil(Math.random() * 11) + 1, Math.ceil(27 * Math.random()) + 1);

        }
        );
        this.headers = Object.keys(this.data[0]).map(x => { return { key: x, val: x, hidden: false } });
        // this.headers = [...this.headers, { key: 'date', val: 'Date' }];
        this.headers[0].hiddenPermanent = true;
        this.headers[1].action = this.action1;
        this.headers[2].action = function (row) {
          alert(JSON.stringify(row));
        }
        this.headers[3].action = function (row) {
          alert(JSON.stringify(row));
        }
        this.headers.push({ type: 'input', key: 'input', val: 'input' });
        this.headers.push({ type: 'checkbox', key: 'checkbox1', val: 'checkbox1' });
        detector.detectChanges();
      },
      err => console.log(err),
      () => { }
    )
    console.log(this.data);
  }
}
