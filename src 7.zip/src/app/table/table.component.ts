import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';
import { ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Observable, } from 'rxjs';
import { startWith, map, retryWhen } from 'rxjs/operators';
import { UtilityService } from '../utility.service';
import { Clipboard } from '@angular/cdk/clipboard';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'smart-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit, OnChanges {

  getIndexWithHiddenHeader(index: number,
    headers: Array<{ key: string, val: string, action: any, hidden: boolean, hiddenPermanent: boolean }>): number {
    let cntVisibleHeader = 0;
    let newIndex = 0;
    while (true) {
      while (headers[newIndex].hidden || headers[newIndex].hiddenPermanent) {
        newIndex++;
        continue;
      }
      if (cntVisibleHeader === index) {
        return newIndex;
      }
      cntVisibleHeader++;
      newIndex++;
    }
  }
  dropHeader(event: CdkDragDrop<any[]>) {
    const startIndex = this.getIndexWithHiddenHeader(event.previousIndex, this.headers);
    const endIndex = this.getIndexWithHiddenHeader(event.currentIndex, this.headers);
    console.log(event.previousIndex, event.currentIndex);
    console.log(startIndex, endIndex);
    moveItemInArray(this.headers, startIndex, endIndex);

  }

  dropSortable(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.sorts, event.previousIndex, event.currentIndex);
    this.refresh();
  }

  @Input()
  data: Array<any>;
  @Input()
  fileName: string;
  @Input()
  headers: Array<{ key: string, val: string, action: any, hidden: boolean, hiddenPermanent: boolean }>;
  @Input()
  isSearchAll = true;

  page = 1;
  pageSize = 10;
  total: number;
  results$: Observable<any>;
  sorts = [];
  dirs = { asc: 'desc', desc: '', '': 'asc' };
  oldPageSize = 10;
  columnSearchFG: FormGroup;
  getAllRowsUnfiltered = false;
  closeResult;
  printTable;

  constructor(private service: UtilityService, private datePipe: DatePipe, private fb: FormBuilder,
    private clipboard: Clipboard, private changeDetector: ChangeDetectorRef, private modalService: NgbModal) {
    console.log('constructor');
  }


  copy(): void {
    let copyData = this.data;
    if (!this.getAllRowsUnfiltered) {
      copyData = this.filterTerms(true);
    }

    this.clipboard.copy(this.createCopyText(copyData, this.headers));
  }
  print(): void {
    this.printTable = this.data;
    if (!this.getAllRowsUnfiltered) {
      this.printTable = this.filterTerms(true);
    }
    this.changeDetector.detectChanges();
    var printdata = document.getElementById("printTable").outerHTML;

    var tab = window.open('') as Window;
    tab.document.open();
    tab.document.write(printdata);

    setTimeout(() => {
      tab.stop();
      tab.print();
      tab.close();
      this.printTable = null;
      this.changeDetector.detectChanges();
    }, 1);

  }
  createCopyText(data: Array<any>, headers: Array<{ key: string, val: string }>): string {
    const dataStr = data.map(row =>
      headers.reduce((prev, next) => [...prev, row[next.key]], []).join('\t')
    ).join('\n');
    return headers.reduce((prev, next) => [...prev, next.val], []).join('\t') + '\n' + dataStr;
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('ngchnages');
    if (!this.headers) {
      return;
    }
    this.total = this.data?.length;
    const ctrls = this.headers.reduce((prev, next) => ({ ...prev, [next.key]: [null] }), {});
    this.columnSearchFG = this.fb.group(ctrls);
    this.columnSearchFG.addControl('searchTerm', new FormControl());
    this.results$ = this.columnSearchFG.valueChanges.pipe(
      startWith(''),
      map(term => {
        return this.filterTerms();
      }));
  }

  toggleSort(key: string) {
    const sortObject = this.sorts.find(x => x.key === key);
    sortObject.dir = this.dirs[sortObject.dir];
    this.refresh();
  }

  sortBy(key: string, event) {
    const withCtrlKey = event.metaKey || event.ctrlKey;
    const sortObject = this.sorts.find(x => x.key === key);
    if (sortObject) {
      if (this.sorts.length === 1 || withCtrlKey) {
        sortObject.dir = this.dirs[sortObject.dir];
      } else {
        this.sorts = [{ dir: 'asc', key }];
      }
    }
    else {
      if (withCtrlKey) {
        this.sorts.push({ dir: 'asc', key });
      }
      else {
        this.sorts = [{ dir: 'asc', key }];
      }
    }
    this.searchTerm.setValue(this.term);
  }

  filterTerms(exportExcel = false): Array<any> {
    const headers = this.headers.filter(x => !x.hidden && !x.hiddenPermanent).map(x => x.key);
    let filtered;
    if (this.isSearchAll) {
      filtered = this.service.filter(this.data, headers, this.term);
    } else {
      console.log('fitlered is ');
      console.log('headers are ', headers);
      console.log(headers.map(x => this.columnSearchFG.controls[x].value));
      filtered = this.service.filterTerms(this.data, headers, headers.map(x => this.columnSearchFG.controls[x].value));
    }
    return this.sortAndPaginateFiltered(filtered, exportExcel);
  }

  sortAndPaginateFiltered(filtered: Array<any>, exportExcel = false): Array<any> {
    if (filtered.length <= this.pageSize) {
      this.page = 1;
    }

    this.total = filtered.length;
    const sorted = this.service.sort([...filtered], this.sorts.map(x => x.key),
      this.sorts.map(x => x.dir === 'asc' ? true : (x.dir === 'desc' ? false : null)));
    if (this.pageSize === null) {
      this.oldPageSize = null;
    }
    if (this.pageSize === null || exportExcel) {
      return sorted;
    }
    this.page = this.service.setPageSize(this.pageSize, this.page, this.oldPageSize, sorted.length);
    const startIndex = (this.page - 1) * this.pageSize;

    this.oldPageSize = this.pageSize;

    return sorted.slice(startIndex, startIndex + this.pageSize);
  }

  ngOnInit(): void {
    console.log('inngoninit');
    if (!this.data) {
      return;
    }
    this.total = this.data?.length;
  }

  get searchTerm() {
    return this.columnSearchFG.get('searchTerm');
  }

  get term() {
    return this.columnSearchFG.get('searchTerm').value;
  }

  set setTerm(term: string) {
    this.searchTerm.setValue(term);
  }

  refresh() {
    this.setTerm = this.term;
  }

  getSortByKey(key: string) {
    return this.sorts.find(x => x.key === key);
  }

  toDate(date: Date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  isDate(data: any): boolean {
    return this.service.isDate(data);
  }

  changePageSize(event) {

    this.refresh();
  }

  exportToExcel() {
    let exportTable = this.data;
    if (!this.getAllRowsUnfiltered) {
      exportTable = this.filterTerms(true);
    }
    this.service.exportToExcel(this.headers, exportTable, this.fileName);
  }

  removeSort(x: string) {
    this.sorts = this.sorts.filter(sort => sort.key != x);
    this.refresh();
  }

  load() {

  }

  bringLeft() {
    for (let i = 0; i < this.sorts.length; i++) {
      const index = this.headers.findIndex(x => x.key ===
        this.sorts[this.sorts.length - 1 - i].key);
      console.log('index is ', index);
      moveItemInArray(this.headers, index, 0);
    }
  }

  clearSorts() {
    this.sorts = [];
  }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${(reason)}`;
    });
  }
  openRowsModal(chooseRowsContent) {
    this.modalService.open(chooseRowsContent, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${(reason)}`;
    });
  }
  sortsContainsKey(key: string): boolean {
    return this.sorts.find(sort => sort.key === key) == null;
  }

  usingFilter(): boolean {
    if (!this.columnSearchFG) {
      return false;
    }
    if (this.isSearchAll) {
      return this.columnSearchFG.get('searchTerm').value?.length > 0;
    }
    for (var i = 0; i < this.headers.length; i++) {
      if (this.columnSearchFG.get(this.headers[i].key).value?.length > 0) {
        return true;
      }
    }
    return false;
  }

  getNoRows(): number {
    console.log('this.getAllRowsUnfiltered');
    console.log(this.getAllRowsUnfiltered);
    if (this.getAllRowsUnfiltered) {
      this.data.length;
    }
    return this.total;
  }
}

